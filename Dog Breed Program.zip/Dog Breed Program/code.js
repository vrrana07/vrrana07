//image links to picture websites 
//https://www.istockphoto.com/photo/canine-unit-gm155099701-18186989?phrase=german+shepherd+police+dog&searchscope=image%2Cfilm  
// https://www.freeimages.com/photo/german-shepherd-dog-1526372 
// https://dawesarb.org/dawgs-at-dawes/ 
//https://www.istockphoto.com/photo/golden-retriever-dog-gm1252455620-365559764?phrase=golden+retriever+running&searchscope=image%2Cfilm  
//https://www.freeimages.com/photo/buda-sit-1401269  
//https://www.freeimages.com/photo/hiking-bulldogs-2-1407656  
onEvent("gRButton", "click", function( ) {
  setScreen("goldenretrieverscreen")
});
onEvent("homebuttongolden", "click", function( ) {
  setScreen("homescreen")
});
onEvent("GoldenBD", "click", function( ) {
  setScreen("goldenretrieverscreen")
});
onEvent("GoldenbuttonGS", "click", function( ) {
  setScreen("goldenretrieverscreen");
});
// https://pixabay.com/photos/dog-pet-animal-cute-1839808/
onEvent("goldenretervierImagehomescreen", "click", function( ) {
  playSound("assets/category_animals/dog.mp3", false);
});
onEvent("gSButton", "click", function( ) {
  setScreen("germanShepherdScreen")
});
onEvent("homebuttongerman", "click", function( ) {
  setScreen("homescreen")
});
onEvent("bulldogButton", "click", function( ) {
  setScreen("bullDogScreen")
});
onEvent("homebuttonfrombulldog", "click", function( ) {
  setScreen("homescreen")
});
onEvent("bullDogbuttonGS", "click", function( ) {
  setScreen("bullDogScreen")
});
onEvent("bulldogbuttonGR", "click", function( ) {
  setScreen("bullDogScreen")
});
onEvent("germanBD", "click", function( ) {
  setScreen("germanShepherdScreen")
});
onEvent("germanButtonGR", "click", function( ) {
  setScreen("germanShepherdScreen")
});
// https://pixabay.com/photos/bulldog-dog-puppy-pet-black-dog-1047518/
onEvent("bulldoghomeimagehomescreen", "click", function( ) {
  stopSound("assets/category_animals/dog.mp3");
});
// https://www.pickpik.com/german-shepherd-dog-german-shepherd-german-police-dog-dog-alsatian-dog-animal-70773  
onEvent("germansheaperdPicturehomescreen", "click", function( ) {
  stopSound("assets/category_animals/dog.mp3");
});
